require "test_helper"

class RegistroAccesoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
