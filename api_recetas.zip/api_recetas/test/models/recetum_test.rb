require "test_helper"

class RecetumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
