class UsersController < ApplicationController
    def sign_in
      puts "Iniciando sesión..."
      user = User.find_by(email: params[:user][:email])  # Cambia esto
  
      puts "Usuario encontrado: #{user.inspect}"
      
      if user && user.valid_password?(params[:user][:password])  # Usa valid_password en vez de authenticate
        token = JsonWebToken.encode(user_id: user.id) # Asegúrate de que este método esté definido
        render json: { token: token, user: { id: user.id, email: user.email } }, status: :ok
      else
        render json: { error: 'Credenciales inválidas' }, status: :unauthorized
      end
    end
  end
  