class RecetasController < ApplicationController
   # Descomenta si necesitas autenticación
  before_action :set_recetum, only: %i[show update destroy]

  # GET /recetas
  def index
    @recetas = Recetum.all
    render json: @recetas
  end

  # GET /recetas/:id
  def show
    render json: @recetum
  end

  # POST /recetas
  def create
    @recetum = Recetum.new(recetum_params)
    if @recetum.save
      render json: @recetum, status: :created
    else
      render json: @recetum.errors, status: :unprocessable_entity
    end
  end

  # PUT/PATCH /recetas/:id
  def update
    if @recetum.update(recetum_params)
      render json: @recetum, status: :ok
    else
      render json: @recetum.errors, status: :unprocessable_entity
    end
  end

  # DELETE /recetas/:id
  def destroy
    @recetum.destroy
    head :no_content
  end

  private

  # Método para buscar la receta por ID
  def set_recetum
    @recetum = Recetum.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    render json: { error: "Receta no encontrada" }, status: :not_found
  end

  # Parámetros permitidos para recetas
  def recetum_params
    params.require(:recetum).permit(:nombre, :ingredientes, :instrucciones)
  end
end
