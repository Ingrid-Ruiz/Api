class Users::SessionsController < ApplicationController
    def create
      user = User.find_by(email: params[:user][:email])
      
      if user && user.valid_password?(params[:user][:password])
        token = generate_jwt(user.id)
        render json: { token: token, user: { id: user.id, email: user.email } }, status: :ok
      else
        render json: { error: 'Credenciales inválidas' }, status: :unauthorized
      end
    end
    
    private
    
    def generate_jwt(user_id)
      JWT.encode({ user_id: user_id, exp: 24.hours.from_now.to_i }, Rails.application.secrets.secret_key_base)
    end
  end
  