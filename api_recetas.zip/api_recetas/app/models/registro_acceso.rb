class RegistroAcceso < ApplicationRecord
  belongs_to :user
end
