class Recetum < ApplicationRecord
   
        validates :nombre, presence: true
        validates :ingredientes, presence: true
        validates :instrucciones, presence: true
      
end
